import React, { Component } from 'react';
import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import { withStyles } from "@material-ui/core/styles";

const styles = (theme) => ({
    root: {
        '& > *': {
            margin: theme.spacing(1),
            width: '25ch',
        },
    },
});

class FormInput extends Component {

    state = {
        name: '',
        city: ''
    }

    formChangeHandler = (event) => {

        this.setState({ name: event.target.value })
    }

    formSubmitHandler = (event) => {
        event.preventDefault();
        console.log(this.state.name);

    }

    render() {

        const { classes } = this.props;

        return (
            <form className={classes.root} noValidate autoComplete='off' onSubmit={this.formSubmitHandler}>
                <TextField id="standard-basic" label="Name" onChange={this.formChangeHandler} /><br />
                <TextField id="standard-basic" label="City" /><br /><br />
                <Button variant="contained" color="secondary" type='submit'>Submit</Button>
            </form>
        );
    }
}

export default withStyles(styles, { withTheme: true })(FormInput);



