import React from 'react';
import './App.css';
import FormInput from './FormInput/FromInput';

function App() {
  return (
    <div>
      <FormInput />
    </div>
  );
}

export default App;
