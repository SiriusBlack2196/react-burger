import React, { Component } from 'react'
import Auxilary from '../Auxilary/Auxilary';
import classes from './Layout.css'
import Toolbar from '../../components/Navigation/Toolbar/Toolbar';
import Sidebar from '../../components/Navigation/Sidebar/Sidebar';


class Layout extends Component {

    state = {
        showSidebar: false
    }

    sidebarClosedHandler = () => {
        this.setState({ showSidebar: false });
    }

    sidebarOpenHandler = () => {
        this.setState({ showSidebar: true });
    }

    render() {
        return (
            <Auxilary>
                <Toolbar openMenu={this.sidebarOpenHandler} />
                <Sidebar open={this.state.showSidebar} closed={this.sidebarClosedHandler} />
                <main className={classes.Content}>
                    {this.props.children}
                </main>
            </Auxilary>
        );
    }
}

export default Layout;