import axios from 'axios';

const instance = axios.create({
    baseURL: 'https://react-burger-builder-955b6.firebaseio.com/'
});

export default instance;