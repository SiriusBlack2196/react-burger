import React from 'react'
import classes from './Order.css'

const order = (props) => {

    const ingredients = [];
    for (let ingredientName in props.ingredients) {
        ingredients.push({
            name: ingredientName,
            amount: props.ingredients[ingredientName]
        });
    }

    const IngredientOutput = ingredients.map(ig => {
        return <p
            key={ig.name}
            style={{
                textTransform: 'capitalize',
                display: 'inline-block',
                padding: '5px'
            }}
        >{ig.name}  [{ig.amount}] </p>;
    });
    return (
        <div className={classes.Order}>
            <p><strong>Ingredients: </strong>{IngredientOutput}</p>
            <p><strong>Price: </strong>${Number.parseFloat(props.price).toFixed(2)}</p>
        </div>
    );
};

export default order;