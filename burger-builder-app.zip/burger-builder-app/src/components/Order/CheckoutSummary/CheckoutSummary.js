import React from 'react';
import Burger from '../../Burger/Burger';
import Button from '../../UI/Button/Button';
import classes from './CheckoutSummary.css';

const checkoutSummary = (props) => {
    return (
        <div className={classes.CheckoutSummary}>
            <div style={{ width: '100%', margin: 'auto' }}>
                <Burger ingredients={props.ingredients} />
            </div>
            <div className={classes.OrderPanel}>
                <h2>Thats a delicious looking burger!</h2>
                <p>Do you want to order this burger ?</p>
                <div className={classes.ButtonsPanel}>
                    <Button
                        btnType="Danger"
                        clicked={props.checkoutCancelled}>Cancel</Button>
                </div>
                <div className={classes.ButtonsPanel}>
                    <Button
                        btnType="Success"
                        clicked={props.checkoutContinued}>Continue</Button>
                </div>
            </div>
        </div>
    );
};

export default checkoutSummary;