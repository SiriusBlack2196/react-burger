import React from 'react';
import classes from './Menu.css';
import hamburgerIcon from '../../../../assests/images/Hamburger_icon.svg.png';

const menu = (props) => {
    return (
        <div
            className={classes.Menu}
            onClick={props.openMenu}>
            <img className={classes.Icon} src={hamburgerIcon} alt='hamberger-icon'/>
        </div>
    )
}

export default menu;