import React from 'react';
import classes from './Toolbar.css';
import Logo from '../../Logo/Logo';
import NavigationItems from '../NavigationItems/NavigationItems';
import Menu from '../Sidebar/Menu/Menu';

const toolbar = (props) => {
    return (
        <header className={classes.Toolbar}>
            <div className={classes.Logo}>
                <Logo height={'130%'} />
            </div>
            <Menu openMenu={props.openMenu} />
            <nav className={classes.nav}>
                <NavigationItems />
            </nav>
        </header>
        
    );
};

export default toolbar;