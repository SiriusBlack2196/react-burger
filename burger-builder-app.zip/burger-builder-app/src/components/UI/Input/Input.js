import React from 'react';
import classes from './Input.css';
import TextField from '@material-ui/core/TextField';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import InputLabel from '@material-ui/core/InputLabel';

const input = (props) => {

    let inputElement = null;
    let errorMessage = null;
    const inputClasses = [classes.InputElement];

    if (props.invalid && props.shouldValidate && props.touched) {
        inputClasses.push(classes.Invalid);
    }

    if (props.invalid && props.touched) {
        errorMessage = <div style={{ textAlign: 'left' }}>
            <small style={{ color: 'red' }}>*Please enter a valid {props.valueType}</small>
        </div>
    }
    console.log(inputClasses);
    switch (props.elementType) {
        case ('input'): inputElement = <TextField
            className={inputClasses.join(' ')}
            {...props.elementConfig}
            value={props.value}
            onChange={props.changed} />;
            break;
        case ('textarea'): inputElement = <TextField
            className={inputClasses.join(' ')}
            {...props.elementConfig}
            value={props.value}
            onChange={props.changed} />;
            break;
        case ('select'): inputElement =
            (<div style={{ textAlign: 'left' }}>
                <InputLabel id="demo-simple-select-label">{props.elementConfig.label}</InputLabel>
                <Select
                    labelId="demo-simple-select-label"
                    className={inputClasses.join(' ')}
                    value={props.value}

                    onChange={props.changed} >
                    {props.elementConfig.options.map(option => (
                        <MenuItem
                            key={option.value}
                            value={option.value}>
                            {option.displayValue}
                        </MenuItem>
                    ))}
                </Select>
            </div>)
            break;
        default: inputElement = <input
            className={inputClasses.join(' ')}
            {...props.elementConfig}
            value={props.value}
            onChange={props.changed} />;
    }

    return (<div className={classes.Input}>
        <label className={classes.Label}>{props.label}</label>
        {inputElement}
        {errorMessage}
    </div>);
}

export default input;