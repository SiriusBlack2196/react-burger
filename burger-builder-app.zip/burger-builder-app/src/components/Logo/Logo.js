import React from 'react';
import burgerLogo from '../../assests/images/burger-builder.png';
import classes from './Logo.css';

const logo = (props) => {
    return (<div className={classes.Logo}>
        <img className={classes.img} src={burgerLogo} alt="MyBurger"></img>
    </div>)
}

export default logo;