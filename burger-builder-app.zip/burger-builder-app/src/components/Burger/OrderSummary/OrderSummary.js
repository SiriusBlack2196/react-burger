import React, { Component } from 'react';
import Auxilary from '../../../hoc/Auxilary/Auxilary';
import Button from '../../UI/Button/Button';
import classes from './OrderSummary.css';

class OrderSummary extends Component {
    render() {
        const ingredientSummary = Object.keys(this.props.ingredients)
            .map(igKey => {
                return (<li key={igKey}>
                    <span style={{ textTransform: 'capitalize' }}>{igKey} x{this.props.ingredients[igKey]}</span>
                </li>)
            })
        return (<Auxilary>
            <h3>Your Order</h3>
            <p>Your Burger includes the following toppings:</p>
            <ul>
                {ingredientSummary}
            </ul>
            <p>Total Price: <strong className={classes.Price}>${this.props.price.toFixed(2)}</strong></p>
            <div className={classes.ButtonsPanel}><Button btnType='Success' clicked={this.props.cancel}>Cancel</Button></div>
            <div className={classes.ButtonsPanel}><Button btnType='Success' clicked={this.props.continue}>Checkout</Button></div>
        </Auxilary>)
    }
}

export default OrderSummary;