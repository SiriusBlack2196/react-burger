import React from 'react';
import classes from './Burger.css';
import BurgerIngredeint from './BurgerIngredient/BurgerIngredient';
import burgerText from '../../assests/images/build-burger.png';

const burger = (props) => {
    let transformedIngredients = Object.keys(props.ingredients)
        .map((igKey) => {
            return [...Array(props.ingredients[igKey])]
                .map((_, i) => {
                    console.log(i);
                    return <BurgerIngredeint key={igKey + i} type={igKey} />
                });
        }).reduce((arr, el) => {
            return arr.concat(el);
        }, []);

    if (transformedIngredients.length === 0) {
        transformedIngredients =
            <div>
                <img className={classes.Message} src={burgerText} alt='Burger Text'></img>
            </div >
    }

    console.log(transformedIngredients);
    return (
        <div className={classes.Burger}>
            <BurgerIngredeint type='bread-top' />
            {transformedIngredients}
            <BurgerIngredeint type='bread-bottom' />
        </div>
    );
};

export default burger;