import React from 'react';

const PageNotFound = () => (
    <h1>Oops! Page Not Found</h1>
)

export default PageNotFound;