import React, { Component } from 'react';

class CoursesPage extends Component {
    state = {
        course: {
            title: ''
        }
    };

    handleChnage = (event) => {
        const course = { ...this.state.course, title: event.target.value };
        this, this.setState({ course: course })
    }

    handleSubmit = (event) => {
        alert('submit works');
    }

    render() {
        return (
            <form onSubmit={this.handleSubmit}>
                <h2>Courses</h2>
                <h3>Add Course</h3>
                <input
                    type='text'
                    onChange={this.handleChnage}
                    value={this.state.course.title} />
                <input
                    type='submit'
                    value='Save' />
            </form>
        )
    }
}

export default CoursesPage;