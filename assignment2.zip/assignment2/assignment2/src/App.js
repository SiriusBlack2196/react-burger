import React, { Component } from 'react';
import './App.css';
import ValidationComponent from './ValidationComponent/ValidationComponent'
import CharComponent from './CharComponent/CharComponent'

class App extends Component {

  state = {
    inputText: ''
  }

  inputChnageListner = (event) => {
    this.setState({
      inputText: event.target.value
    })

  }

  deleteCharHandler = (charIndex) => {

    const charList = this.state.inputText.split('');
    charList.splice(charIndex, 1);
    const inputText = charList.join('');
    this.setState({
      inputText: inputText
    })

  }

  render() {

    const charList = this.state.inputText.split('').map((ch, index) => {
      return <CharComponent
        character={ch} key={index}
        clicked={() => this.deleteCharHandler(index)} />
    })


    return (
      <div className="App">
        <input type='text' onChange={(event) => this.inputChnageListner(event)} />
        <p>{this.state.inputText.length}</p>
        <ValidationComponent textLength={this.state.inputText.length} value={this.state.inputText} />
        {charList}
      </div>
    );
  }
}

export default App;
