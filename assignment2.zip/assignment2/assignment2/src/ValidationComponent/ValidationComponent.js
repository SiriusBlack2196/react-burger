import React from 'react';

const validate = (props) => {

    let message = 'Text Long enough';

    if (props.textLength < 5) {
        message = 'Text too short';
    }
    else if (props.textLength > 10) {
        message = 'Text too long';
    }

    return (
        <div>
            {message}
        </div>
    )
}

export default validate;