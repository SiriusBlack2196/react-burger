import React from 'react';

const eachChar = (props) => {

    const style = {
        backgroundColor: 'black',
        font: 'inherit',
        border: '1px solid red',
        padding: '8px',
        color: 'white',
        cursor: 'pointer'
    }
    return (
        <div style={style} onClick={props.clicked}>
            {props.character}
        </div>
    )
}

export default eachChar;