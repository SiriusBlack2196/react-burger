import React, { Component } from 'react';
import Person from './Person/Person'

class Persons extends Component {

    shouldComponentUpdate(nextProps, nextState) {
        console.log('[Persons.js] shoudComponentUpdate');
        return true;
    }

    componentDidUpdate(prevProps) {
        console.log(prevProps, this.props);

    }

    render() {
        console.log('[Persons.js] rendering...');
        console.log(this.props.loginStatus);

        return this.props.persons.map((person, index) => {
            return (
                <Person
                    click={this.props.clicked.bind(index)}
                    name={person.name}
                    age={person.age}
                    key={person.id}
                    changed={(event) => this.props.changed(event, person.id)}
                />
            );
        })
    }
}
export default Persons;