import React, { Component } from 'react';
import cssClasses from './Person.css';
import Auxiliary from '../../../hoc/Auxiliary';
import withClass from '../../../hoc/withClass';
import PropTypes from 'prop-types';
import AuthContext from '../../../context/auth-context';

class Person extends Component {

    constructor(props) {
        super(props);
        this.inputElementRef = React.createRef();
    }

    componentDidMount() {
        this.inputElementRef.current.focus();
    }
    componentDidUpdate(prevProps) {
        console.log(prevProps, this.props);

    }

    static contextType = AuthContext;

    render() {
        console.log('[Person.js] rendering...');
        return (
            <Auxiliary>
                {this.context.authenticated ? <p>Authenticated!</p> : <p>Please Authenticate</p>}
                <p onClick={this.props.click}>I'm {this.props.name} and I am {this.props.age} years old</p>
                <p>{this.props.children}</p>
                <input type='text'
                    onChange={this.props.changed}
                    ref={this.inputElementRef}
                    value={this.props.name}
                />
            </Auxiliary>
        );
    }
}

Person.propType = {
    click: PropTypes.func,
    name: PropTypes.string,
    age: PropTypes.number,
    changed: PropTypes.func
};

export default withClass(Person, cssClasses.Person);