import React, { useEffect, useRef, useContext } from 'react';
import cssClasses from './Cockpit.css';
import AuthContext from '../../context/auth-context';
const cockpit = (props) => {

    const toggleButtonRef = useRef(null);
    const authContext = useContext(AuthContext);

    useEffect(() => {
        console.log('[Cockpit.js] useEffect');
        toggleButtonRef.current.click();
    }, []);

    let btnClasses = [cssClasses.Button];
    let classes = []
    if (props.showPersons) {
        btnClasses.push(cssClasses.Blue);
    }
    if (props.personsLength <= 2) {
        classes.push(cssClasses.red);
    }
    if (props.personsLength <= 1) {
        classes.push(cssClasses.bold);
    }

    return (
        <div>
            <h1>{props.title}</h1>
            <p className={classes.join(' ')}>This is really working</p>
            <button
                ref={toggleButtonRef}
                className={btnClasses.join(' ')} onClick={props.clicked}>Toggle Name
            </button>
            <button className={btnClasses} onClick={authContext.login}>Login</button>
        </div>
    );
};

export default React.memo(cockpit);