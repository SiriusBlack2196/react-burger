import React from 'react';
import classes from './Header.module.css';
import { NavLink } from 'react-router-dom';

const header = () => {
    return (
        <div className={classes.Header}>
            <div style={{ float: 'right' }}>
                <ul className={classes.NavigationItems}>
                    <li><NavLink to='/' >Check-In</NavLink></li>
                    <li><NavLink to='/in-flight' >In-Flight</NavLink></li>
                </ul>
            </div>
        </div>
    );
};

export default header;