import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import Flight from '../../components/Flight/Flight';
import classes from './Check-In.module.css';

class CheckIn extends Component {
    state = {
        flights: [
            { id: '123a', flightName: 'BZE0Y', airLineName: 'Indigo', price: 'Rs.4500', date: '29/4/2020' },
            { id: '123b', flightName: 'ETY09', airLineName: 'Emirates', price: 'Rs.7500', date: '29/4/2020' },
            { id: '123c', flightName: 'LIG67', airLineName: 'Ethihad', price: 'Rs.10000', date: '29/4/2020' },
            { id: '123d', flightName: 'BHY41', airLineName: 'Air Asia', price: 'Rs.2300', date: '29/4/2020' },
            { id: '123e', flightName: 'MKA06', airLineName: 'Go Air', price: 'Rs.3800', date: '29/4/2020' }
        ]
    }
    render() {

        let flights = this.state.flights.map(flight => {
            return (<Link key={flight.id} to={'/' + flight.id} className={classes.TextLink}>
                <Flight
                    flightName={flight.flightName}
                    airLineName={flight.airLineName}
                    price={flight.price}
                    date={flight.date}
                />
            </Link>);
        });

        return (
            <div className={classes.Flights}>
                {flights}
            </div>

        );
    };
}

export default CheckIn;