import React, { Component } from 'react';

class InFlight extends Component {

    render() {
        return (
            <h1>The InFlight Component</h1>
        )
    }
}

export default InFlight;