import React from 'react';
import './App.css';
import Header from './UI/Header/Header';
import { Route, Switch } from 'react-router-dom';
import FlightDetails from './components/FlightDetails/FlightDetails';
import CheckIn from './containers/Check-In/Check-In';
import InFlight from './containers/In-Flight/In-Flight';

function App() {
  return (
    <div>
      <Header />
      <div style={{ marginTop: '70px' }}>
        <Switch>
          <Route path='/' exact component={CheckIn} />
          <Route path='/in-flight' component={InFlight} />
          <Route path='/:id' exact component={FlightDetails} />
        </Switch>
      </div>
    </div>
  );
}

export default App;
