import React from 'react';

const flightDetails = (props) => {

    return (
        <h1>Flight Details</h1>
    );
};

export default flightDetails;