import React, { Component } from 'react';
import UserInput from './UserInput/UserInput';
import UserOut from './UserOutput/UserOutput';
import './App.css';

class App extends Component {
  state = {
    username: 'Abk'
  }

  userNameHandler = (event) => {
    this.setState({
      username: event.target.value
    })
  }

  render() {
    return (
      <div className="App" >
        <UserInput username={this.state.username} change={this.userNameHandler} />
        <UserOut username={this.state.username} />
        <UserOut />
        <UserOut />
      </div>
    );
  }
}

export default App;
