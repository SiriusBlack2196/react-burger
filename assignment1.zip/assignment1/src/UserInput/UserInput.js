import React from 'react';
import './UserInput.css'
const input = (props) => {
    return (<div className='UserInput'>
        Username:
        <br />
        <input onChange={props.change} placeholder='Enter your Username' type='text' value={props.username} />
    </div>)
}

export default input;