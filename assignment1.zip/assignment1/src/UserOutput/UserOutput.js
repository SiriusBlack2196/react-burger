import React from 'react';
import './UserOutput.css'
const output = (props) => {
    return (<div className='UserOutput'>
        <p>Your Username: {props.username}</p>
    </div>)
}

export default output;