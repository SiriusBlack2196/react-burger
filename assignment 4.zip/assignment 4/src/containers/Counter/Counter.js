import React, { Component } from 'react';
import { connect } from 'react-redux';
import CounterControl from '../../components/CounterControl/CounterControl';
import CounterOutput from '../../components/CounterOutput/CounterOutput';
import * as actionTyoes from '../../store/actions';

class Counter extends Component {

    render() {
        return (
            <div>
                <CounterOutput value={this.props.ctr} />
                <CounterControl label="Increment" clicked={this.props.onIncrementCounter} />
                <CounterControl label="Decrement" clicked={this.props.onDecrementCounter} />
                <CounterControl label="Add 5" clicked={this.props.onAddCounter} />
                <CounterControl label="Subtract 5" clicked={this.props.onSubtractCounter} />
                <hr />
                <button onClick={() => this.props.onStoreResult(this.props.ctr)}>Store Result</button>
                <ul>
                    {this.props.storedResults.map(storedResult => (
                        <li key={storedResult.id} onClick={() => this.props.onDeleteResult(storedResult.id)}>{storedResult.value}</li>
                    ))}
                </ul>
            </div>
        );
    }
}

const mapStateToProps = state => {
    return {
        ctr: state.ctr.counter,
        storedResults: state.res.results
    };
};

const mapDispatchToProps = dispatch => {
    return {
        onIncrementCounter: () => dispatch({ type: actionTyoes.INCREMENT, value: 1 }),
        onDecrementCounter: () => dispatch({ type: actionTyoes.DECREMENT, value: 1 }),
        onAddCounter: () => dispatch({ type: actionTyoes.ADD, value: 5 }),
        onSubtractCounter: () => dispatch({ type: actionTyoes.SUBTRACT, value: 5 }),
        onStoreResult: (result) => dispatch({ type: actionTyoes.STORE_RESULT, result: result }),
        onDeleteResult: (id) => dispatch({ type: actionTyoes.DELETE_RESULT, resultId: id })
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(Counter);