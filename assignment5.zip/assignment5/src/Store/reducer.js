const initialState = {
    persons: []
}

const reducer = (state = initialState, action) => {

    const newPerson = {
        id: Math.random(), // not really unique but good enough here!
        name: 'Max',
        age: Math.floor(Math.random() * 40)
    }
    if (action.type === 'ADD') {
        return {
            ...state, persons: state.persons.concat(newPerson)
        }
    }
    else if (action.type === 'DELETE') {
        const updatedArray = state.persons.filter((person) => person.id !== action.value);
        return {
            ...state, persons: updatedArray
        }
    }
    else return state;
}

export default reducer;